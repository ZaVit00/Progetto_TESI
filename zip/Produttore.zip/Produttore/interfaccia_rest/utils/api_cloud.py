import logging
import requests

from costanti_comuni import TipoServizio
from costanti_produttore import API_KEY_PRODUTTORE
from istanza_globale_db  import gestore_db
from registro_log import setup_logger

logger = setup_logger(TipoServizio.PRODUTTORE, module = __name__, level=logging.DEBUG)
logging.getLogger("urllib3.connectionpool").setLevel(logging.CRITICAL)


def invia_payload(payload_dict: dict, endpoint_cloud: str) -> bool:
    """
    Invia un payload al cloud e gestisce la conferma di ricezione.
    Esegue la POST HTTP e, se la risposta è valida, richiama la funzione
    che elabora e registra la conferma nel database.
    """
    try:
        headers = {
            "X-API-Key": API_KEY_PRODUTTORE
        }
        response = requests.post(endpoint_cloud, json=payload_dict, headers=headers, timeout=10)
        response.raise_for_status()
        risposta_json = response.json()
        logger.debug(f"[HTTP] Risposta dal cloud: {risposta_json}")

        # Elabora la risposta ricevuta, aggiorna il DB e ritorna True/False in base all'esito
        # dell'operazione
        return elabora_conferma_ricezione_cloud(risposta_json)

    except requests.exceptions.Timeout:
        logger.error("Timeout durante l'invio del payload al cloud.")
    except requests.exceptions.ConnectionError:
        logger.error("Connessione al cloud fallita.")
    except requests.RequestException as e:
        logger.error(f"Invio del payload fallito: {e}")
    except ValueError:
        logger.error("Risposta del cloud non è in formato JSON valido.")

    return False

def elabora_conferma_ricezione_cloud(risposta: dict) -> bool:
    """
    Elabora la risposta ricevuta dal cloud e aggiorna la conferma nel database locale.
    Restituisce True se la conferma è valida e gestita correttamente.
    In questo caso il cloud può avere due tipologie di conferma ricezione:
    1) id_sensori -> se nel JSON ricevuto compare questo campo significa che il cloud sta
        riscontrando la corretta ricezione di un gruppo di sensori
    2) id_batch -> se nel JSON compare questo campo significa che il cloud sta
        riscontrando un gruppo di misurazioni ricevute correttamente e che
        corrispondono a un batch (significato logico del batch)
    """
    if not risposta or not risposta.get("conferma_ricezione"):
        logger.warning(f"[CLOUD] Nessuna conferma ricevuta o struttura non valida: {risposta}")
        return False

    id_sensori = risposta.get("id_sensori", []) #estrae la lista di sensori se presenti
    if id_sensori:
        return gestore_db.aggiorna_conferma_ricezione_sensori(id_sensori)
    elif "id_batch" in risposta:
        return gestore_db.aggiorna_conferma_ricezione_batch(risposta["id_batch"])

    logger.warning(f"[CLOUD] Risposta ricevuta ma mancano ID riconoscibili: {risposta}")
    return False

